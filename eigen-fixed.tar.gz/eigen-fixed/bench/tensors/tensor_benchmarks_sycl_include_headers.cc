#include "tensor_benchmarks_sycl.cc"
#include "tensor_benchmarks_sycl.sycl"
